from datetime import datetime, timezone
from app.main import epoch_ms, from_epoch_ms, attendance_day, calculate_derived


def test_epoch_ms_round_trip():
    value = datetime(2026, 7, 6, 3, 58, tzinfo=timezone.utc)
    assert epoch_ms(from_epoch_ms(epoch_ms(value))) == epoch_ms(value)


def test_overnight_attendance_day_uses_shift_start_date():
    employee = {"shift_start": "22:00", "shift_end": "06:00"}
    now = datetime(2026, 7, 7, 1, 10, tzinfo=timezone.utc)  # 06:40 IST
    assert attendance_day(now, employee) == "2026-07-06"


def test_sample_overtime_below_threshold_is_zero():
    employee = {"shift_start": "09:30", "shift_end": "18:30"}
    punch_in = datetime(2026, 7, 6, 3, 58, tzinfo=timezone.utc)
    punch_out = datetime(2026, 7, 6, 13, 5, tzinfo=timezone.utc)
    result = calculate_derived(employee, "2026-07-06", punch_in, punch_out, "PRESENT")
    assert result["work_hours"] == 9.12
    assert result["overtime_minutes"] == 0
    assert result["late_minutes"] == 0


def test_half_day_threshold():
    employee = {"shift_start": "09:30", "shift_end": "18:30"}
    punch_in = datetime(2026, 7, 7, 4, 0, tzinfo=timezone.utc)
    punch_out = datetime(2026, 7, 7, 7, 30, tzinfo=timezone.utc)
    result = calculate_derived(employee, "2026-07-07", punch_in, punch_out, "WFH")
    assert result["work_hours"] == 3.5
    assert result["half_day"] is True
