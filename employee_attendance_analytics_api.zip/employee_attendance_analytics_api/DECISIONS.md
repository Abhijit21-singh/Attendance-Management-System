# Design Decisions

## Data model

- Use `emp_code` as the business key; never expose or accept MongoDB `_id` as an API identifier.
- Use only `employees` and `attendance_logs`, matching the supplied data model.
- Store attendance `date` and employee `joined_on` as ISO calendar-date strings. Store instants as BSON dates in UTC.
- Convert API epoch milliseconds to aware UTC datetimes at the boundary. PyMongo's naive datetime results are interpreted as UTC.
- Keep correction audit history embedded in each attendance document, matching the required schema.

## Integrity and indexes

- Create a unique index on `employees.emp_code`.
- Create a unique compound index on `attendance_logs(emp_code, date)` to enforce at most one record per employee/attendance day.
- Add date and employee/date indexes for common filters.
- Let MongoDB enforce uniqueness under concurrent requests; convert duplicate-key failures into HTTP 409 responses.

## Time and calculations

- Use `Asia/Kolkata` for shift calendar interpretation, while storing event instants in UTC.
- Resolve overnight shift dates to the date the shift starts.
- Calculate derived values at punch-in/out and correction time; analytics aggregate stored values only.
- Sample data suggests 30 minutes as the overtime minimum and 4.50 hours as the half-day threshold. Verify both against R1–R10.

## Corrections

- A correction requires `by` and `reason`.
- Compare old and new values and append exactly one history entry containing only changed fields.
- Store history timestamps and nested punch values as BSON dates. API serialization converts those nested dates to epoch milliseconds.

## Known uncertainty

The official OpenAPI contract and R1–R10 were not supplied in the material available for this draft. Route names, error schemas, and edge-case semantics must be reconciled against those files before submission. No claim is made that this provisional API exactly matches the grader contract.
