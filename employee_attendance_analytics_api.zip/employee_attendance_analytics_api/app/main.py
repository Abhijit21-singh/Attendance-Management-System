"""Employee Attendance & Analytics API.

The data model is based on the candidate-provided DATA_MODEL.md. Exact paths and
some business-rule details must be reconciled with the assignment's openapi.yaml
before submission because that file was not provided in this conversation.
"""
from contextlib import asynccontextmanager
from datetime import date, datetime, time, timedelta, timezone
from typing import Any, Literal
from zoneinfo import ZoneInfo
import os, re

from bson import ObjectId
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import DuplicateKeyError, PyMongoError

IST = ZoneInfo("Asia/Kolkata")
UTC = timezone.utc
MONGO_URI = os.getenv("MONGO_URI", os.getenv("MONGODB_URI", "mongodb://localhost:27017"))
MONGO_DB = os.getenv("MONGO_DB", os.getenv("DATABASE_NAME", "attendance_db"))
# The sample data establishes a 30-minute minimum for counted overtime and a
# 4.50-hour half-day threshold. Late minutes are measured from shift_start.
OVERTIME_MINIMUM_MINUTES = 30
HALF_DAY_HOURS = 4.50
PRESENT_STATUSES = {"PRESENT", "WFH", "ON_DUTY"}
ALL_STATUSES = PRESENT_STATUSES | {"ABSENT", "LEAVE"}

client: MongoClient | None = None
db = None
employees = None
attendance_logs = None


def utc_now() -> datetime:
    return datetime.now(UTC)


def as_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    # PyMongo returns naive datetimes by default; those represent UTC.
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def epoch_ms(value: datetime | None) -> int | None:
    value = as_utc(value)
    return int(value.timestamp() * 1000) if value else None


def from_epoch_ms(value: int | None) -> datetime | None:
    return datetime.fromtimestamp(value / 1000, tz=UTC) if value is not None else None


def ist_datetime(day: str, hhmm: str) -> datetime:
    d = date.fromisoformat(day)
    t = time.fromisoformat(hhmm)
    return datetime.combine(d, t, tzinfo=IST)


def attendance_day(now: datetime, employee: dict[str, Any]) -> str:
    """Resolve the shift-start attendance date, including overnight shifts."""
    local = as_utc(now).astimezone(IST)
    start = time.fromisoformat(employee["shift_start"])
    end = time.fromisoformat(employee["shift_end"])
    if end <= start and local.time().replace(tzinfo=None) < end:
        return (local.date() - timedelta(days=1)).isoformat()
    return local.date().isoformat()


def shift_end_datetime(day: str, employee: dict[str, Any]) -> datetime:
    start = time.fromisoformat(employee["shift_start"])
    end = time.fromisoformat(employee["shift_end"])
    d = date.fromisoformat(day)
    if end <= start:
        d += timedelta(days=1)
    return datetime.combine(d, end, tzinfo=IST).astimezone(UTC)


def calculate_derived(employee: dict[str, Any], day: str, punch_in: datetime | None,
                      punch_out: datetime | None, status: str) -> dict[str, Any]:
    if status not in PRESENT_STATUSES or punch_in is None:
        return {"work_hours": None, "late_minutes": 0, "overtime_minutes": 0, "half_day": False}
    local_in = as_utc(punch_in).astimezone(IST)
    shift_start = ist_datetime(day, employee["shift_start"])
    late = max(0, int((local_in - shift_start).total_seconds() // 60))
    if punch_out is None:
        return {"work_hours": None, "late_minutes": late, "overtime_minutes": 0, "half_day": False}
    local_out_utc = as_utc(punch_out)
    if local_out_utc <= as_utc(punch_in):
        raise HTTPException(status_code=422, detail="punch_out must be after punch_in")
    minutes = (local_out_utc - as_utc(punch_in)).total_seconds() / 60
    hours = round(minutes / 60, 2)
    shift_end = shift_end_datetime(day, employee)
    raw_overtime = max(0, int((local_out_utc - shift_end).total_seconds() // 60))
    overtime = raw_overtime if raw_overtime >= OVERTIME_MINIMUM_MINUTES else 0
    return {"work_hours": hours, "late_minutes": late, "overtime_minutes": overtime,
            "half_day": hours < HALF_DAY_HOURS}


def clean_doc(doc: dict[str, Any] | None) -> dict[str, Any] | None:
    if doc is None:
        return None
    result = dict(doc)
    result.pop("_id", None)
    for key in ("created_at", "punch_in", "punch_out"):
        if key in result:
            result[key] = epoch_ms(result[key])
    history = []
    for item in result.get("history", []) or []:
        entry = dict(item)
        entry["at"] = epoch_ms(entry.get("at"))
        changes = {}
        for field, delta in (entry.get("changes") or {}).items():
            delta = dict(delta)
            if field in {"punch_in", "punch_out"}:
                delta["from"] = epoch_ms(delta.get("from"))
                delta["to"] = epoch_ms(delta.get("to"))
            changes[field] = delta
        entry["changes"] = changes
        history.append(entry)
    if "history" in result or history:
        result["history"] = history
    result.setdefault("late_minutes", 0)
    result.setdefault("overtime_minutes", 0)
    result.setdefault("half_day", False)
    return result


def validate_day(value: str) -> str:
    try:
        return date.fromisoformat(value).isoformat()
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="date must be YYYY-MM-DD")


def ensure_indexes() -> None:
    employees.create_index([("emp_code", ASCENDING)], unique=True, name="uq_emp_code")
    attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING)], unique=True,
                                 name="uq_attendance_emp_date")
    attendance_logs.create_index([("date", ASCENDING)], name="ix_attendance_date")
    attendance_logs.create_index([("emp_code", ASCENDING), ("date", DESCENDING)], name="ix_emp_date")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global client, db, employees, attendance_logs
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=4000, tz_aware=False)
    db = client[MONGO_DB]
    employees = db["employees"]
    attendance_logs = db["attendance_logs"]
    try:
        client.admin.command("ping")
        ensure_indexes()
    except Exception:
        client.close()
        client = db = employees = attendance_logs = None
        raise
    yield
    if client is not None:
        client.close()

app = FastAPI(title="Employee Attendance & Analytics API", version="1.0.0",
              description="Attendance punch, correction audit trail and MongoDB aggregation analytics.", lifespan=lifespan)

class EmployeeCreate(BaseModel):
    emp_code: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    department: str = Field(min_length=1, max_length=100)
    shift_start: str = Field(pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    shift_end: str = Field(pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    joined_on: str
    @field_validator("joined_on")
    @classmethod
    def valid_joined_on(cls, v):
        try: date.fromisoformat(v)
        except ValueError: raise ValueError("joined_on must be YYYY-MM-DD")
        if len(v) != 10: raise ValueError("joined_on must be YYYY-MM-DD")
        return v

class PunchRequest(BaseModel):
    emp_code: str = Field(min_length=1, max_length=64)
    status: Literal["PRESENT", "WFH", "ON_DUTY"] = "PRESENT"

class CorrectionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    by: str = Field(min_length=1, max_length=120)
    reason: str = Field(min_length=1, max_length=500)
    status: Literal["PRESENT", "WFH", "ON_DUTY", "ABSENT", "LEAVE"] | None = None
    punch_in: int | None = None
    punch_out: int | None = None

class ErrorResponse(BaseModel):
    detail: str

@app.get("/health")
def health():
    try:
        client.admin.command("ping")
        return {"status": "ok"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail="MongoDB unavailable") from exc

@app.post("/employees", status_code=201)
def create_employee(payload: EmployeeCreate):
    doc = payload.model_dump()
    doc["created_at"] = utc_now()
    try:
        employees.insert_one(doc)
    except DuplicateKeyError as exc:
        raise HTTPException(status_code=409, detail="emp_code already exists") from exc
    return clean_doc(doc)

@app.get("/employees")
def list_employees(department: str | None = None):
    query = {"department": department} if department is not None else {}
    return [clean_doc(x) for x in employees.find(query, {"_id": 0}).sort("emp_code", ASCENDING)]

@app.get("/employees/{emp_code}")
def get_employee(emp_code: str):
    doc = employees.find_one({"emp_code": emp_code}, {"_id": 0})
    if not doc: raise HTTPException(status_code=404, detail="Employee not found")
    return clean_doc(doc)

@app.post("/attendance/punch-in", status_code=201)
def punch_in(payload: PunchRequest):
    employee = employees.find_one({"emp_code": payload.emp_code})
    if not employee: raise HTTPException(status_code=404, detail="Employee not found")
    now = utc_now(); day = attendance_day(now, employee)
    if day < employee["joined_on"]: raise HTTPException(status_code=422, detail="Employee has not joined yet")
    existing = attendance_logs.find_one({"emp_code": payload.emp_code, "date": day})
    if existing: raise HTTPException(status_code=409, detail="Attendance already exists for this shift date")
    derived = calculate_derived(employee, day, now, None, payload.status)
    doc = {"emp_code": payload.emp_code, "date": day, "status": payload.status,
           "punch_in": now, "punch_out": None, **derived, "history": []}
    try: attendance_logs.insert_one(doc)
    except DuplicateKeyError as exc: raise HTTPException(status_code=409, detail="Attendance already exists") from exc
    return clean_doc(doc)

@app.post("/attendance/punch-out")
def punch_out(payload: PunchRequest):
    employee = employees.find_one({"emp_code": payload.emp_code})
    if not employee: raise HTTPException(status_code=404, detail="Employee not found")
    now = utc_now(); day = attendance_day(now, employee)
    record = attendance_logs.find_one({"emp_code": payload.emp_code, "date": day})
    # If shift-day resolution is on the following date for a non-overnight shift,
    # check the current local date as a fallback for a record made earlier today.
    if not record:
        local_day = now.astimezone(IST).date().isoformat()
        record = attendance_logs.find_one({"emp_code": payload.emp_code, "date": local_day})
        day = local_day
    if not record: raise HTTPException(status_code=404, detail="No open attendance record found")
    if record.get("punch_in") is None or record.get("status") not in PRESENT_STATUSES:
        raise HTTPException(status_code=409, detail="Record is not an open presence record")
    if record.get("punch_out") is not None: raise HTTPException(status_code=409, detail="Already punched out")
    derived = calculate_derived(employee, record["date"], record["punch_in"], now, record["status"])
    attendance_logs.update_one({"emp_code": payload.emp_code, "date": record["date"], "punch_out": None},
                               {"$set": {"punch_out": now, **derived}})
    updated = attendance_logs.find_one({"emp_code": payload.emp_code, "date": record["date"]})
    if updated.get("punch_out") is None: raise HTTPException(status_code=409, detail="Attendance was changed concurrently")
    return clean_doc(updated)

@app.get("/attendance")
def list_attendance(emp_code: str | None = None, start_date: str | None = None,
                    end_date: str | None = None, status: str | None = None):
    query: dict[str, Any] = {}
    if emp_code: query["emp_code"] = emp_code
    if status:
        if status not in ALL_STATUSES: raise HTTPException(status_code=422, detail="Invalid status")
        query["status"] = status
    if start_date or end_date:
        bounds = {}
        if start_date: bounds["$gte"] = validate_day(start_date)
        if end_date: bounds["$lte"] = validate_day(end_date)
        if start_date and end_date and start_date > end_date: raise HTTPException(status_code=422, detail="start_date must not exceed end_date")
        query["date"] = bounds
    return [clean_doc(x) for x in attendance_logs.find(query, {"_id": 0}).sort([("date", DESCENDING), ("emp_code", ASCENDING)])]

@app.get("/attendance/{emp_code}/{day}")
def get_attendance(emp_code: str, day: str):
    day = validate_day(day)
    doc = attendance_logs.find_one({"emp_code": emp_code, "date": day}, {"_id": 0})
    if not doc: raise HTTPException(status_code=404, detail="Attendance record not found")
    return clean_doc(doc)

@app.patch("/attendance/{emp_code}/{day}/correct")
def correct_attendance(emp_code: str, day: str, payload: CorrectionRequest):
    day = validate_day(day)
    record = attendance_logs.find_one({"emp_code": emp_code, "date": day})
    if not record: raise HTTPException(status_code=404, detail="Attendance record not found")
    employee = employees.find_one({"emp_code": emp_code})
    if not employee: raise HTTPException(status_code=404, detail="Employee not found")
    old_status = record.get("status")
    new_status = payload.status if payload.status is not None else old_status
    old_in, old_out = record.get("punch_in"), record.get("punch_out")
    new_in = from_epoch_ms(payload.punch_in) if payload.punch_in is not None else old_in
    new_out = from_epoch_ms(payload.punch_out) if payload.punch_out is not None else old_out
    if new_status in {"ABSENT", "LEAVE"}:
        new_in = new_out = None
    elif new_in is None:
        raise HTTPException(status_code=422, detail="Presence status requires punch_in")
    derived = calculate_derived(employee, day, new_in, new_out, new_status)
    old_values = {"status": old_status, "punch_in": old_in, "punch_out": old_out,
                  "work_hours": record.get("work_hours"), "late_minutes": record.get("late_minutes", 0),
                  "overtime_minutes": record.get("overtime_minutes", 0), "half_day": record.get("half_day", False)}
    new_values = {"status": new_status, "punch_in": new_in, "punch_out": new_out, **derived}
    changes = {}
    for field, new_value in new_values.items():
        old_value = old_values.get(field)
        if field in {"punch_in", "punch_out"}:
            old_value, new_value = as_utc(old_value), as_utc(new_value)
        if old_value != new_value:
            changes[field] = {"from": old_value, "to": new_value}
    if not changes:
        raise HTTPException(status_code=422, detail="Correction does not change any fields")
    now = utc_now()
    history_entry = {"at": now, "by": payload.by, "reason": payload.reason, "changes": changes}
    result = attendance_logs.update_one({"_id": record["_id"]},
        {"$set": {"status": new_status, "punch_in": new_in, "punch_out": new_out, **derived},
         "$push": {"history": history_entry}})
    if result.modified_count != 1: raise HTTPException(status_code=409, detail="Record changed concurrently")
    return clean_doc(attendance_logs.find_one({"_id": record["_id"]}, {"_id": 0}))

@app.get("/analytics/daily")
def daily_analytics(start_date: str = Query(...), end_date: str = Query(...), department: str | None = None):
    start_date, end_date = validate_day(start_date), validate_day(end_date)
    if start_date > end_date: raise HTTPException(status_code=422, detail="start_date must not exceed end_date")
    match: dict[str, Any] = {"date": {"$gte": start_date, "$lte": end_date}}
    pipeline = [{"$match": match}, {"$lookup": {"from": "employees", "localField": "emp_code", "foreignField": "emp_code", "as": "employee"}},
                {"$unwind": {"path": "$employee", "preserveNullAndEmptyArrays": False}}]
    if department is not None: pipeline.append({"$match": {"employee.department": department}})
    pipeline += [{"$group": {"_id": "$date", "total_records": {"$sum": 1},
        "present_count": {"$sum": {"$cond": [{"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$cond": [{"$eq": ["$half_day", True]}, 0.5, 1]}, 0]}},
        "absent_count": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
        "leave_count": {"$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}},
        "total_work_hours": {"$sum": {"$ifNull": ["$work_hours", 0]}},
        "total_overtime_minutes": {"$sum": {"$ifNull": ["$overtime_minutes", 0]}},
        "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}}}}, {"$sort": {"_id": 1}},
        {"$project": {"_id": 0, "date": "$_id", "total_records": 1, "present_count": 1, "absent_count": 1, "leave_count": 1,
                       "total_work_hours": {"$round": ["$total_work_hours", 2]}, "total_overtime_minutes": 1, "late_count": 1}}]
    return list(attendance_logs.aggregate(pipeline))

@app.get("/analytics/employees")
def employee_analytics(start_date: str = Query(...), end_date: str = Query(...), department: str | None = None):
    start_date, end_date = validate_day(start_date), validate_day(end_date)
    if start_date > end_date: raise HTTPException(status_code=422, detail="start_date must not exceed end_date")
    pipeline: list[dict[str, Any]] = [
      {"$match": {"date": {"$gte": start_date, "$lte": end_date}}},
      {"$group": {"_id": "$emp_code", "days_recorded": {"$sum": 1},
        "present_days": {"$sum": {"$cond": [{"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$cond": [{"$eq": ["$half_day", True]}, 0.5, 1]}, 0]}},
        "absent_days": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
        "leave_days": {"$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}},
        "work_hours": {"$sum": {"$ifNull": ["$work_hours", 0]}},
        "overtime_minutes": {"$sum": {"$ifNull": ["$overtime_minutes", 0]}},
        "late_days": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}}}},
      {"$lookup": {"from": "employees", "localField": "_id", "foreignField": "emp_code", "as": "employee"}},
      {"$unwind": "$employee"}]
    if department is not None: pipeline.append({"$match": {"employee.department": department}})
    pipeline += [{"$project": {"_id": 0, "emp_code": "$_id", "name": "$employee.name", "department": "$employee.department",
          "days_recorded": 1, "present_days": 1, "absent_days": 1, "leave_days": 1,
          "work_hours": {"$round": ["$work_hours", 2]}, "overtime_minutes": 1, "late_days": 1}}, {"$sort": {"emp_code": 1}}]
    # Employees without logs are intentionally not synthesized here; contract may define otherwise.
    return list(attendance_logs.aggregate(pipeline))

@app.get("/analytics/department")
def department_analytics(start_date: str = Query(...), end_date: str = Query(...)):
    start_date, end_date = validate_day(start_date), validate_day(end_date)
    if start_date > end_date: raise HTTPException(status_code=422, detail="start_date must not exceed end_date")
    pipeline = [
      {"$match": {"date": {"$gte": start_date, "$lte": end_date}}},
      {"$lookup": {"from": "employees", "localField": "emp_code", "foreignField": "emp_code", "as": "employee"}},
      {"$unwind": "$employee"},
      {"$group": {"_id": "$employee.department", "records": {"$sum": 1},
        "present_days": {"$sum": {"$cond": [{"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$cond": [{"$eq": ["$half_day", True]}, 0.5, 1]}, 0]}},
        "work_hours": {"$sum": {"$ifNull": ["$work_hours", 0]}}, "overtime_minutes": {"$sum": {"$ifNull": ["$overtime_minutes", 0]}}}},
      {"$project": {"_id": 0, "department": "$_id", "records": 1, "present_days": 1,
                    "work_hours": {"$round": ["$work_hours", 2]}, "overtime_minutes": 1}}, {"$sort": {"department": 1}}]
    return list(attendance_logs.aggregate(pipeline))
