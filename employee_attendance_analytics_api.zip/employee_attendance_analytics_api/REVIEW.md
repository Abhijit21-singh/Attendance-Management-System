# Starter Code Review

## Scope limitation

The assignment's supplied starter application was not included in the material available while preparing this project. This document therefore cannot honestly claim findings about specific lines in that starter. Replace this section with concrete file/line references after reviewing the official starter code.

## Risks the implementation must avoid

1. **Wrong collection or key names** — use `attendance_logs` and `emp_code`, not generic `attendance`, `employee_id`, or MongoDB `_id` as the business key.
2. **Non-unique attendance records** — enforce unique `(emp_code, date)` with a MongoDB index, not only an application pre-check.
3. **Timezone confusion** — treat naive PyMongo datetimes as UTC and interpret shift dates/times in IST.
4. **Overnight shifts** — attendance `date` refers to shift-start day, even if punch-out occurs the next calendar day.
5. **Client-controlled derived fields** — never accept `work_hours`, `late_minutes`, `overtime_minutes`, or `half_day` from clients.
6. **Incomplete audit trail** — correction history belongs inside the attendance document, records only changed fields, and stores nested punch values as BSON dates.
7. **Analytics recomputation** — analytics must use the stored derived values, not derive them again from punch timestamps.
8. **Legacy documents** — missing `history`, `half_day`, `late_minutes`, and `overtime_minutes` must be handled with defaults.
9. **Employees with no logs and mid-month joiners** — analytics must follow the official contract's population and working-day rules; these cannot be finalized without R1–R10 and OpenAPI.
10. **Unverified endpoint contract** — the paths and schemas in this draft are provisional until compared with `openapi.yaml`.

## Recommended verification

- Compare every endpoint, status code, query parameter, and response schema against the official OpenAPI file.
- Run tests for overnight shifts, tied timestamps, duplicate punches, seeded legacy records, corrections that change no values, and analytics with employees having no logs.
