# Employee Attendance & Analytics API

A FastAPI + MongoDB implementation based on the supplied `DATA_MODEL.md` excerpt. It supports employee creation/listing, attendance punch-in/out, manual corrections with an embedded audit history, attendance queries, and aggregation-based analytics.

> **Contract limitation:** `openapi.yaml`, R1–R10, the supplied starter app, and the required templates were not included in the material available here. Therefore route names, request/response shapes, and some rule details below are reasonable implementations based on `DATA_MODEL.md`, not a verified match to the grader contract. Compare every route with the official OpenAPI file before submission.

## Requirements

- Python 3.11+
- MongoDB 6+

## Run locally

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
# Set MONGO_URI and MONGO_DB in your environment; defaults target local MongoDB.
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` for interactive API documentation. `/health` checks the MongoDB connection.

## Environment

- `MONGO_URI` (also accepts legacy `MONGODB_URI`): MongoDB connection string.
- `MONGO_DB` (also accepts legacy `DATABASE_NAME`): database name.

No secrets should be committed. `.env.example` contains placeholders only.

## MongoDB data model

Uses exactly `employees` and `attendance_logs`. `emp_code` is the business identifier. Calendar dates are `YYYY-MM-DD` strings; instants are BSON UTC dates; API instants are epoch milliseconds. MongoDB `_id` is never returned. Indexes are created at startup: unique employee code and unique `(emp_code, date)` attendance, plus query indexes.

## Implemented routes

- `POST /employees`, `GET /employees`, `GET /employees/{emp_code}`
- `POST /attendance/punch-in`, `POST /attendance/punch-out`
- `GET /attendance`, `GET /attendance/{emp_code}/{day}`
- `PATCH /attendance/{emp_code}/{day}/correct`
- `GET /analytics/daily`, `GET /analytics/employees`, `GET /analytics/department`

These are provisional route shapes until checked against `openapi.yaml`.

## Business-rule assumptions to verify

- Attendance day is the local IST date on which the shift starts, including overnight shifts.
- Work hours are elapsed punch duration in hours, rounded to two decimals.
- Overtime is elapsed time after scheduled shift end and only counts if at least 30 minutes.
- Half-day is true below 4.50 hours.
- Late minutes are whole minutes after shift start; early/on-time punches produce zero.
- `PRESENT`, `WFH`, and `ON_DUTY` count as present; half-days count as 0.5.

The official R1–R10 rules take precedence over these assumptions.

## Notes

- Analytics read stored `work_hours`, `late_minutes`, `overtime_minutes`, and `half_day`; they do not recompute these values from timestamps.
- Corrections append one embedded `history` item and record only changed fields. Punch events do not write to history.
- The API does not create `ABSENT` or `LEAVE` during normal punch endpoints; these can be represented through manual correction or seeded data.
- The code deliberately uses synchronous PyMongo calls in synchronous FastAPI route functions.

## Before submission

1. Obtain and compare with the official `openapi.yaml` and R1–R10.
2. Run automated tests and exercise all routes against a real MongoDB instance.
3. Review `REVIEW.md` and update it with findings from the actual starter app (not supplied here).
4. Ensure the GitHub repository contains no secrets or `.env` files.
5. Be prepared to explain every implementation decision in the live interview.
